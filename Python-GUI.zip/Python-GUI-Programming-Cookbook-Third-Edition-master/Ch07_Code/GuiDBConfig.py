'''
Created on May 29, 2019
Ch07
@author: Burkhard A. Meier
'''


# create dictionary to hold connection info
dbConfig = {
    'user': 'Admin',
    'password': 'admin',
    'host': '127.0.0.1',
    }


# # create dictionary to hold connection info
# dbConfig = {
#     'user': <adminUser>,        # your user name
#     'password': <adminPwd>,     # your password
#     'host': '127.0.0.1',
#     }

