'''
Created on Jun 9, 2019
Ch08
@author: Burkhard A. Meier
'''

import unittest 
 
class GuiUnitTests(unittest.TestCase): 
    pass 
 
if __name__ == '__main__': 
    unittest.main() 
    